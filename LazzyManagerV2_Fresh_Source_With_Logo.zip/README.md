# Lazzy Manager V2 (fresh Android project)

A native Kotlin Android file manager starter with two independent panels.

## Included
- Dual-pane browsing using Android's Storage Access Framework (SAF)
- Separate folder selection for left and right panels
- Persisted folder permissions (Android remembers the selected folder access)
- Copy and move between panels, including recursive folder copy
- Rename, delete, create folder, refresh, and swap panels
- Minimum Android 6.0 (API 23), targeting Android 15 (API 35)

## Build
1. Install Android Studio and a JDK 17.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Important Android storage limitation
This app uses Android's official Storage Access Framework. The user chooses a folder once per panel and the app persists that grant. It does not bypass Android restrictions. Some protected locations (notably parts of Android/data and Android/obb) may be unavailable or restricted depending on the Android version/device. This is intentional and safer than requesting broad all-files access by default.

This is source code, not a prebuilt or tested APK. Build and test on a device before relying on it. Some storage providers may not support every rename/delete/copy operation.
